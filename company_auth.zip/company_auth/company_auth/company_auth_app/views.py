from django.shortcuts import render, redirect
from company_auth_app.models import UserInsert,UserRetrive,editupdaterecord, deletedetails
from django.contrib import messages
from company_auth_app.forms import empforms
from sqlite3 import IntegrityError
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.db import IntegrityError


def Insertrecord(request):
    if request.method=='POST':
        if request.POST.get('company_name') and request.POST.get('company_website') and request.POST.get('company_phone_number')  and request.POST.get('company_address') and request.POST.get('company_city') and request.POST.get('company_state') and request.POST.get('company_country') and request.POST.get('industry_list'):
            saverecord = UserInsert()
            saverecord.company_name = request.POST.get('company_name')
            saverecord.company_website = request.POST.get('company_website')
            saverecord.company_phone_number = request.POST.get('company_phone_number')
            saverecord.company_address = request.POST.get('company_address')
            saverecord.company_city = request.POST.get('company_city')
            saverecord.company_state = request.POST.get('company_state')
            saverecord.company_country = request.POST.get('company_country')
            saverecord.industry_list = request.POST.get('industry_list')
            saverecord.save()
            messages.success(request,'Record Saved')
            return render(request, 'send.html')
    else:
        return render(request,'send.html')

def showrecord(request):
    resultsdisplay=UserRetrive.objects.all()
    return render(request,"retrive.html",{'UserRetrive':resultsdisplay})

def home(request):
    return render(request, 'welcome.html')


def edittemp(request, id):
    displaydetails = editupdaterecord.objects.get(id=id)
    return render(request,"edit.html",{"editupdaterecord":displaydetails})


def updatecomp(request, id):
    updatecomp = editupdaterecord.objects.get(id=id)
    form=empforms(request.POST,instance=updatecomp)
    if form.is_valid():
        form.save()
        messages.success(request,'Record Updated Successfully..')
        return render(request,"edit.html",{"editupdaterecord":updatecomp})  

def deletecomp(request, id):
    resultsdisplay=UserRetrive.objects.all()
    deletecomp = deletedetails.objects.filter(id=id)
    deletecomp.delete()
    messages.success(request,'Record Deleted Successfully..')
    return render(request,"retrive.html",{'UserRetrive':resultsdisplay})
 
def signNewUser(request):
    if request.method == "POST":
        if request.POST.get('password1') == request.POST.get('password2'):
            try:
                saveuser = User.objects.create_user(request.POST.get(
                    'username'), password=request.POST.get('password1'))
                saveuser.save()
                return render(request, 'signup.html', {'form': UserCreationForm(), 'info': 'The User '+request.POST.get('username')+' is saved sucessfully'})
            except IntegrityError:
                return render(request, 'signup.html', {'form': UserCreationForm(), 'info': 'The User '+request.POST.get('username')+' Already exists'})
        else:
            return render(request, 'signup.html', {'form': UserCreationForm(), 'error': 'the passwords do not match'})
    else:
        return render(request, 'signup.html', {'form': UserCreationForm})


def loginuser(request):
    if request.method == "POST":
        loginsuccess = authenticate(request, username=request.POST.get(
            'username'), password=request.POST.get('password'))
        if loginsuccess is None:
            return render(request, 'login.html', {'form': AuthenticationForm(), 'error': 'the user name and passwords are wrong'})
        else:
            login(request, loginsuccess)
            return redirect('welcomepage')
    else:
        return render(request, 'login.html', {'form': AuthenticationForm()})


def welcomepage(request):
    return render(request, 'home.html')


def logoutpage(request):
    if request.method == "POST":
        logout(request)
        return redirect('loginuser')
