from django.db import models
from django.db import connections


class UserInsert(models.Model):
    company_name = models.CharField(max_length=100)
    company_website = models.CharField(max_length=100)
    company_phone_number = models.CharField(max_length=100)
    company_address = models.CharField(max_length=100)
    company_city = models.CharField(max_length=100)
    company_state = models.CharField(max_length=100)
    company_country = models.CharField(max_length=100)
    industry_list = models.CharField(max_length=100)
    class Meta:
        db_table = "user_auth_table"
        managed = False

class UserRetrive(models.Model):
    company_name = models.CharField(max_length=100)
    company_website = models.CharField(max_length=100)
    company_phone_number = models.CharField(max_length=100)
    company_address = models.CharField(max_length=100)
    company_city = models.CharField(max_length=100)
    company_state = models.CharField(max_length=100)
    company_country = models.CharField(max_length=100)
    industry_list = models.CharField(max_length=100)
    class Meta:
        db_table = "user_auth_table"
        managed = False

class editupdaterecord(models.Model):
    company_name = models.CharField(max_length=100)
    company_website = models.CharField(max_length=100)
    company_phone_number = models.CharField(max_length=100)
    company_address = models.CharField(max_length=100)
    company_city = models.CharField(max_length=100)
    company_state = models.CharField(max_length=100)
    company_country = models.CharField(max_length=100)
    industry_list = models.CharField(max_length=100)
    class Meta:
        db_table = "user_auth_table"

class deletedetails(models.Model):
    company_name = models.CharField(max_length=100)
    company_website = models.CharField(max_length=100)
    company_phone_number = models.CharField(max_length=100)
    company_address = models.CharField(max_length=100)
    company_city = models.CharField(max_length=100)
    company_state = models.CharField(max_length=100)
    company_country = models.CharField(max_length=100)
    industry_list = models.CharField(max_length=100)
    class Meta:
        db_table = "user_auth_table"
        managed = False

