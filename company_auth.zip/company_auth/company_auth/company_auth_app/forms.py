from django import forms
from company_auth_app.models import editupdaterecord


class empforms(forms.ModelForm):
    class Meta:
        model=editupdaterecord
        fields="__all__"