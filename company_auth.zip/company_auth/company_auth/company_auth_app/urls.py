from django.urls import path
from . import views

urlpatterns = [

    path('save/',views.Insertrecord, name="save"),
    path('retrive/',views.showrecord),
    path('home/',views.home),
    path('edit/<int:id>',views.edittemp),
    path('update/<int:id>',views.updatecomp),
    path('delete/<int:id>',views.deletecomp),

    path('', views.home, name="homepage"),
    path('signup', views.signNewUser, name="signnewuser"),
    path('login', views.loginuser, name="loginuser"),
    path('welcome', views.welcomepage, name="welcomepage"),
    path('logout', views.logoutpage, name="logoutpage"),

]