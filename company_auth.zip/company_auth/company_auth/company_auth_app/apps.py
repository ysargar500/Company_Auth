from django.apps import AppConfig


class CompanyAuthAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'company_auth_app'
